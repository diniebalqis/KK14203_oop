
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
//required for border
import javax.swing.BorderFactory;
import javax.swing.border.Border;
//required for file IO
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.BufferedWriter;
import java.io.BufferedReader;
//required for exception
import java.io.IOException;


//Header 
class Header extends JPanel{
   private JLabel header;
   public Header(){
      	header = new JLabel("CUSTOMER JIDZ CAFE FEEDBACK");
      	add(header);
   }
}

//Feedback
class Feedback extends JPanel implements ActionListener{

   //list all UI components for the panel
    JLabel lbl_rating;
    JRadioButton rb5;
    JRadioButton rb4;
    JRadioButton rb3;
    JRadioButton rb2;
    JRadioButton rb1;
    JLabel lbl_feedback;
    JTextArea ta_feedback;
    JLabel lbl_follow;
    JLabel lbl_ig;
    JLabel lbl_fb;
    JLabel lbl_twit;
    JLabel lbl_contact;
    JLabel lbl_wasap;
    JButton b_submit;
    JButton b_clear;
    JLabel l_output; 
    JScrollPane jsp;
    Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
    
   
   //global variable  
   String output="";
   String rb_selection="";
   String filePath="customerfeedback.txt"; //in the same directory

   public Feedback(){ 
      //adjust size and set layout
      setLayout(new FlowLayout(FlowLayout.LEFT));
              
      lbl_rating = new JLabel ("     RATING JIDZ CAFE");
      lbl_rating.setPreferredSize(new Dimension(150, 35));
      lbl_rating.setBorder(border);
      add (lbl_rating);
      
      //Radio buttons and action listener
      JRadioButton rb1 = new JRadioButton("1");
      rb1.addActionListener(this);
      add(rb1);
      JRadioButton rb2 = new JRadioButton("2");
      rb2.addActionListener(this);
      add(rb2);
      JRadioButton rb3 = new JRadioButton("3");
      rb3.addActionListener(this);
      add(rb3);
      JRadioButton rb4 = new JRadioButton("4");
      rb4.addActionListener(this);
      add(rb4);
      JRadioButton rb5 = new JRadioButton("5");
      rb5.addActionListener(this);
      add(rb5);
      
      //define button group
      ButtonGroup bg = new ButtonGroup();
      bg.add(rb1);
      bg.add(rb2);
      bg.add(rb3);
      bg.add(rb4);
      bg.add(rb5);
      
      lbl_feedback = new JLabel ("  CUSTOMER FEEDBACK ");
      lbl_feedback.setPreferredSize(new Dimension(150, 35));
      lbl_feedback.setBorder(border);
      add (lbl_feedback);
      
      ta_feedback = new JTextArea (3, 42);
      add (ta_feedback);
       
      //input name will not accept any number.
      ta_feedback.addKeyListener(new KeyAdapter() {
         public void keyTyped(KeyEvent e) {
         char c=e.getKeyChar(); 
            if(Character.isAlphabetic(c) || (c==KeyEvent.VK_BACK_SPACE) || (c==KeyEvent.VK_DELETE) || (c==KeyEvent.VK_SPACE)) {
                e = e;
            }
           else{
                e.consume();
            }
         }
      });
      
      lbl_follow = new JLabel ("   FOLLOW US");
      lbl_follow.setPreferredSize(new Dimension(100, 35));
      add(lbl_follow);
      
      lbl_ig = new JLabel ("Intagram:@jidzcafe");
      add(lbl_ig);
      
      lbl_fb = new JLabel ("Facebook:JidzCafe");
      add(lbl_fb);
      
      lbl_twit = new JLabel ("Twitter:@jidzcafe");
      add(lbl_twit);
       
      lbl_contact = new JLabel ("   CONTACT US");
      lbl_contact.setPreferredSize(new Dimension(100, 35));    
      add(lbl_contact);
      
      lbl_wasap = new JLabel ("https://wa.me/60133433473");
      lbl_wasap.setPreferredSize(new Dimension(300, 35)); 
      add(lbl_wasap);

      b_submit = new JButton("Submit");
      b_submit.setPreferredSize(new Dimension(100, 35));
      add(b_submit);
      
      b_clear = new JButton("Clear");
      b_clear.setPreferredSize(new Dimension(100, 35));
      add(b_clear);
      
      //handle button submit action listener
      //view the input to output label
      //and write to file
      b_submit.addActionListener(new ActionListener(){           
         public void actionPerformed(ActionEvent e){  
            //call method
            if(printOutput()){
               writeInput();  
               //show dialog message if input is succesfully saved
               JOptionPane.showMessageDialog(null, "Thank you for your feedback! Have a good day and stay safe.");   
                
            }   
         }  
      });

      //handle button clear action listener
      b_clear.addActionListener(new ActionListener(){  
         public void actionPerformed(ActionEvent e){  
            l_output.setText("Output");  
            ta_feedback.setText("");
            bg.clearSelection();
         }  
      });
      
      l_output = new JLabel("Output");
      l_output.setBorder(border);
      l_output.setVerticalAlignment(JLabel.TOP);
      
      //add output label to scrollpane
      jsp = new JScrollPane(l_output);
      jsp.setPreferredSize(new Dimension(450,200));
      add(jsp);     
   }

   //handle radio button selection
   public void actionPerformed(ActionEvent ae) {
      rb_selection = ae.getActionCommand();    	   
   }
   
   //method to print output to lbl_output
   public boolean printOutput(){
      output = "<html>";
      output += "Dear customer, thank you for your feedback.<br><br>"; 
      output += "We will try our best to improve the service.<br>";
      output += "Hope you will come again, have a nice day.<br><br>";
      output += "Rating: " + rb_selection + "<br>" + "Feedback: " + ta_feedback.getText() + "<br>";
      
      if(rb_selection.equals("") || ta_feedback.getText().equals("")){
         JOptionPane.showMessageDialog(null, "Dear Customer, please give your feedback. Thank you.");
         return false;
      }

      output += "</html>";          
      l_output.setText(output);
      jsp.getViewport().revalidate();
      return true;
      }
    
    //write to file
    public void writeInput(){
      File file = new File(filePath);
		FileWriter fr = null;
		BufferedWriter br = null;
		PrintWriter pr = null;
      
      String input = "Rating: " + rb_selection + ", " + "Feedback: " + ta_feedback.getText();
      
      //exception implementation
		try {
			// to append to file, you need to initialize FileWriter using below constructor
			fr = new FileWriter(file, true);
			br = new BufferedWriter(fr);
			pr = new PrintWriter(br);
			pr.println(input);
		} catch (IOException e) {			
         l_output.setText(e.toString());
		} finally {
			try {
				pr.close();
				br.close();
				fr.close();
			} catch (IOException e) {
				l_output.setText(e.toString());
			}
		}
    }
}

class MenuActionListener5 implements ActionListener {
   Feedback fb;
   //receive Feedback class to this constructor
   public MenuActionListener5(Feedback f){
      fb = f;
}
    
   public void actionPerformed(ActionEvent e) {      
      BufferedReader reader;
	   try {
			reader = new BufferedReader(new FileReader(fb.filePath));
			String line = reader.readLine();
         String output="<html>";
			while (line != null) {
				output += line + "<br>";
				// read next line
				line = reader.readLine();
			}
         output += "<br>";
         fb.l_output.setText(output);
			reader.close();
		} catch (IOException io) {
			fb.l_output.setText(io.toString());
		}
  }
}

class MenuActionListener6 implements ActionListener {
   Feedback fb;
   //receive FormPanel class to this constructor
   public MenuActionListener6(Feedback f){
      fb = f;
}
    
   public void actionPerformed(ActionEvent e) {   
      
      //show confirm dialog to exit application
      int response = JOptionPane.showConfirmDialog(null,"Do you want to Exit? ", 
     "Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);

     if (response == JOptionPane.YES_OPTION)
     {
        System.exit(0);
     } 
  }
}

//run the application using this main
public class CustomerFeedback {  
   public static void main(String[] 	args) {  
      JFrame f = new JFrame("CUSTOMER JIDZS CAFE FEEDBACK");
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
      
      //load panels
      Header h = new 	Header();
      Feedback fb = new Feedback();
      
      JMenuBar mb = new JMenuBar(); 
      // create a menu 
      JMenu x = new JMenu("Menu"); 
      
      // create menuitems 
      JMenuItem m1 = new JMenuItem("Customer Feedback"); 
      // attach listener and send FormPanel class
      m1.addActionListener(new MenuActionListener5(fb));
      
      JMenuItem m2 = new JMenuItem("Exit");
      m2.addActionListener(new MenuActionListener6(fb));
 
      // add menu items to menu 
      x.add(m1); 
      x.add(m2);
     
      // add menu to menu bar 
      mb.add(x); 
      // add menubar to frame 
      f.setJMenuBar(mb); 
                  
      //add panels to frame       
      f.add(h,BorderLayout.NORTH);
      f.add(fb, BorderLayout.CENTER);
      f.setSize(490,550);
      f.setVisible(true);
   }  
}
