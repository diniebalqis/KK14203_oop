import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
//required for border
import javax.swing.BorderFactory;
import javax.swing.border.Border;
//required for file IO
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.BufferedWriter;
import java.io.BufferedReader;
//required for exception
import java.io.IOException;

//Header 
class Header extends JPanel{
   private JLabel header;
   public Header(){
      	header = new JLabel("CUSTOMER JIDZ CAFE DETAILS");
      	add(header);
   }
}

class Detail extends JPanel implements ActionListener{

   //list all UI components for the panel
   JLabel l_name;
   JTextField tf_name;
   JLabel l_phone;
   JTextField tf_phone;
   JLabel l_temp;
   JTextField tf_temp;
   JLabel l_status;
   JButton b_submit;
   JButton b_clear;
   JLabel l_output; 
   JScrollPane jsp;
   Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
   
   //global variable  
   String output="";
   String status_selection="";
   String filePath="customerdetails.txt"; //in the same directory
   double temp;

   public Detail(){   
      setLayout(new FlowLayout(FlowLayout.LEFT));     
      
      l_name = new JLabel("NAME");
      l_name.setPreferredSize(new Dimension(120, 35));
      add(l_name);
      tf_name = new JTextField(26);
      add(tf_name);
      
      //input name will not accept any number.
      tf_name.addKeyListener(new KeyAdapter() {
         public void keyTyped(KeyEvent e) {
         char c=e.getKeyChar(); 
            if(Character.isAlphabetic(c) || (c==KeyEvent.VK_BACK_SPACE) || (c==KeyEvent.VK_DELETE) || (c==KeyEvent.VK_SPACE)) {
                e = e;
            }
           else{
                e.consume();
            }
        }
});
     
      l_phone = new JLabel("PHONE NO.");
      l_phone.setPreferredSize(new Dimension(120, 35));
      add(l_phone);
      tf_phone = new JTextField(26);
      add(tf_phone);
      
      //input phone no. will not accept any alphabetic.
      tf_phone.addKeyListener(new KeyAdapter() {
         public void keyTyped(KeyEvent e) {
         char c=e.getKeyChar(); 
            if(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || (c==KeyEvent.VK_DELETE) || (c==KeyEvent.VK_SPACE)) {
                e = e;
            }
           else{
                e.consume();
            }
        }
});   
      
      l_temp = new JLabel("TEMPERATURE");
      l_temp.setPreferredSize(new Dimension(120, 35));
      add(l_temp);
      tf_temp = new JTextField(26);
      add(tf_temp);  
      
      l_status= new JLabel("STATUS");
      l_status.setPreferredSize(new Dimension(156, 35));
      add(l_status);
      
      //Radio buttons and action listener
      JRadioButton rb1 = new JRadioButton("Dine In");
      rb1.addActionListener(this);
      add(rb1);
      JRadioButton rb2 = new JRadioButton("Take Away");
      rb2.addActionListener(this);
      add(rb2);
      JRadioButton rb3 = new JRadioButton("Delivery");
      rb3.addActionListener(this);
      add(rb3);
      
      //define button group
      ButtonGroup bg = new ButtonGroup();
      bg.add(rb1);
      bg.add(rb2);
      bg.add(rb3);
      
      b_submit = new JButton("Submit");
      add(b_submit);
      b_clear = new JButton("Clear");
      add(b_clear);     
      
      //handle button submit action listener
      //view the input to output label
      //and write to file
      b_submit.addActionListener(new ActionListener(){           
         public void actionPerformed(ActionEvent e){  
            //call method
            if(printOutput()){
               writeInput();  
               //show dialog message if input is succesfully saved
               JOptionPane.showMessageDialog(null, "Customer Detail saved successfully");   
                
            }   
         }  
      });

      //handle button clear action listener
      b_clear.addActionListener(new ActionListener(){  
         public void actionPerformed(ActionEvent e){  
            l_output.setText("Output");  
            tf_name.setText("");
            tf_phone.setText(""); 
            tf_temp.setText(""); 
            bg.clearSelection();
         }  
      });
      
      l_output = new JLabel("Output");
      l_output.setBorder(border);
      l_output.setVerticalAlignment(JLabel.TOP);
      
      //add output label to scrollpane
      jsp = new JScrollPane(l_output);
      jsp.setPreferredSize(new Dimension(450,120));
      add(jsp);     
   }

   //handle radio button selection
   public void actionPerformed(ActionEvent ae) {
      status_selection = ae.getActionCommand();    	   
   }
   
   //method to print output to lbl_output
   public boolean printOutput(){
      output = "<html>";
      output += "Dear customer, thank you for your entering registration.<br><br>"; 
      output += "Name: " + tf_name.getText() + "<br>";
      output += "Phone: " + tf_phone.getText() + "<br>";
      output += "Temperature: " + tf_temp.getText() + "<br>";
      
      if(tf_name.getText().equals("") || tf_phone.getText().equals("") || tf_temp.getText().equals("") || status_selection.equals("")){
         JOptionPane.showMessageDialog(null, "Please fill the entering registration.");
         return false;
      }
      
      temp = Double.parseDouble(tf_temp.getText());
      if(temp>= 35.1 && temp<=37.5) {
         JOptionPane.showMessageDialog(null, "Your temperature is NORMAL. You can dine inside the cafe.");
      }   
      else if(temp<=35.0) {
         JOptionPane.showMessageDialog(null, "You are HYPOTHERMIA. You can dine inside the cafe but please do medical check up.");
      }
      else {   
         JOptionPane.showMessageDialog(null, "You have FEVER. You CANNOT dine inside the cafe and please refer to doctor. ");
      }  

      output += "Status: " + status_selection + "<br>";
      output += "</html>";          
      l_output.setText(output);
      jsp.getViewport().revalidate();
      return true;
    }
    
    //write to file
    public void writeInput(){
      File file = new File(filePath);
		FileWriter fr = null;
		BufferedWriter br = null;
		PrintWriter pr = null;
      
      String input = "Name: " + tf_name.getText() + " , Phone: " + tf_phone.getText() + " , Temperature: " + tf_temp.getText() + " , Status: " + status_selection;
      
      //exception implementation
		try {
			// to append to file, you need to initialize FileWriter using below constructor
			fr = new FileWriter(file, true);
			br = new BufferedWriter(fr);
			pr = new PrintWriter(br);
			pr.println(input);
		} catch (IOException e) {			
         l_output.setText(e.toString());
		} finally {
			try {
				pr.close();
				br.close();
				fr.close();
			} catch (IOException e) {
				l_output.setText(e.toString());
			}
		}
    }
}

class MenuActionListener implements ActionListener {
   Detail dt;
   //receive FormPanel class to this constructor
   public MenuActionListener(Detail d){
      dt = d;
}
    
   public void actionPerformed(ActionEvent e) {      
      BufferedReader reader;
	   try {
			reader = new BufferedReader(new FileReader(dt.filePath));
			String line = reader.readLine();
         String output="<html>";
			while (line != null) {
				output += line + "<br>";
				// read next line
				line = reader.readLine();
			}
         output += "<br>";
         dt.l_output.setText(output);
			reader.close();
		} catch (IOException io) {
			dt.l_output.setText(io.toString());
		}
  }
}

class MenuActionListener2 implements ActionListener {
   Detail dt;
   //receive FormPanel class to this constructor
   public MenuActionListener2(Detail d){
      dt = d;
}
    
   public void actionPerformed(ActionEvent e) {   
      
      //show confirm dialog to exit application
      int response = JOptionPane.showConfirmDialog(null,"Do you want to Exit? ", 
     "Confirm",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);

     if (response == JOptionPane.YES_OPTION)
     {
        System.exit(0);
     } 
  }
}

//run the application using this main
abstract public class CutomerDetail {  
   public static void main(String[] 	args) {  
      JFrame f = new JFrame("CUSTOMER JIDZ CAFE DETAILS");
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
      
      //load panels
      Header h = new 	Header();
      Detail dt = new Detail();
      
      JMenuBar mb = new JMenuBar(); 
      // create a menu 
      JMenu x = new JMenu("Menu"); 
      
      // create menuitems 
      JMenuItem m1 = new JMenuItem("Customer Data"); 
      // attach listener and send FormPanel class
      m1.addActionListener(new MenuActionListener(dt));
      
      JMenuItem m2 = new JMenuItem("Exit");
      m2.addActionListener(new MenuActionListener2(dt));
 
      // add menu items to menu 
      x.add(m1); 
      x.add(m2);
     
      // add menu to menu bar 
      mb.add(x); 
      // add menubar to frame 
      f.setJMenuBar(mb); 
                  
      //add panels to frame       
      f.add(h,BorderLayout.NORTH);
      f.add(dt, BorderLayout.CENTER);
      f.setSize(490,420);
      f.setVisible(true);
   }  
}

