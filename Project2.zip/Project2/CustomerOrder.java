import java.awt.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

//required for border
import javax.swing.BorderFactory;
import javax.swing.border.Border;

//required for file IO
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.BufferedWriter;
import java.io.BufferedReader;

//required for exception
import java.io.IOException;

//required decimal format
import java.text.DecimalFormat;


//CoffeeEspresso
class CoffeeEspresso extends JPanel implements ActionListener, ItemListener{
    DecimalFormat df = new DecimalFormat ("0.00");

    //list all UI components for the panel
    JButton submit;
    JButton clear;
    JLabel l_line;
    JLabel l_line1;
    JLabel l_daebak;
    JLabel l_latte;
    JLabel l_american;
    JLabel l_espresso;
    JLabel l_mocha;
    JLabel l_cappucino;
    JRadioButton rb1;
    JRadioButton rb2;
    JRadioButton rb3;
    JRadioButton rb4;
    JRadioButton rb5;
    JRadioButton rb6;
    JCheckBox cb1;
    JCheckBox cb2;
    JCheckBox cb3;
    JCheckBox cb4;
    JCheckBox cb5;
    JTextField user;
    JLabel l_line2;
    JLabel l_ttl;
    JLabel l_ty;
    JLabel lbloutput; 
    JScrollPane jsp;
    Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
  
    //global variable  
    String output="";
    String list_selection="";
    String rb_selection="";
    String filePath="orderdetail.txt"; //in the same directory
    int ttl=0, mult=0;
    int q;

    public CoffeeEspresso(){  
    
      //adjust size and set layout
      setPreferredSize (new Dimension (600, 700));
      setLayout (null);      

      //JLabel
      l_line = new JLabel ("********************************     COFFEE & ESPRESSO JIDZ CAFE MENU     *******************************");
      l_line.setBounds (15, 15, 565, 25);
      add (l_line);
      
      l_line1 = new JLabel ("           DRINKS TYPE                     PRICE (RM)           ORDER               ADD ON (+RM 3)                    QUANTITY");
      l_line1.setBounds (10, 55, 595, 25);
      add (l_line1);
      
      l_daebak = new JLabel (">>>   COFFEE DAEBAK       ||     RM 5.00");
      l_daebak.setBounds (15, 85, 230, 25);
      add (l_daebak);
      
      l_latte = new JLabel (">>>   CAFFE LATTE              ||     RM 4.00");
      l_latte.setBounds (15, 110, 225, 25);
      add (l_latte);
      
      l_american = new JLabel (">>>   AMERICAN COFFEE   ||     RM 4.00    ");
      l_american.setBounds (15, 135, 235, 25);
      add (l_american);
      
      l_espresso = new JLabel (">>>   ESPRESSO                 ||     RM 5.00");
      l_espresso.setBounds (15, 160, 230, 25);
      add (l_espresso);
      
      l_mocha = new JLabel (">>>   MOCHA                        ||     RM 5.00");
      l_mocha.setBounds (15, 185, 225, 25);
      add (l_mocha);
      
      l_cappucino = new JLabel (">>>   CAPPUCINO                ||     RM 5.00");   
      l_cappucino.setBounds (15, 210, 220, 25);
      add (l_cappucino);
      
      l_line2 = new JLabel ("*************************************     TOTAL PRICE FOR YOUR ORDER    ************************************");
      l_line2.setBounds (15, 285, 575, 25);
      add (l_line2);
      
      l_ttl = new JLabel ("TOTAL:");
      l_ttl.setBounds (15, 305, 115, 25);
      add (l_ttl);
      
      l_ty = new JLabel ("*************************************                        THANK YOU                        ************************************");
      l_ty.setBounds (15, 380, 580, 25);
      add (l_ty);
             
      //JCheckbox and item listener
      cb1 = new JCheckBox ("WHIPPED CREAM");
      cb1.setBounds (345, 85, 130, 25);
      cb1.addItemListener (this);
      add (cb1);
      
      cb2 = new JCheckBox ("CRUMBLES");
      cb2.setBounds (345, 110, 120, 25);
      cb2.addItemListener (this);
      add (cb2);      
      
      cb3 = new JCheckBox ("DRIZZLES");
      cb3.setBounds (345, 135, 100, 25);
      cb3.addItemListener (this);
      add (cb3);  
      
      cb4 = new JCheckBox ("SPICE");
      cb4.setBounds (345, 160, 100, 25);
      cb4.addItemListener (this);
      add (cb4);  
      
      cb5 = new JCheckBox ("BOBA");
      cb5.setBounds (345, 185, 100, 25);
      cb5.addItemListener (this);
      add (cb5);  
      
      //JRadioButton and action listener
      rb1 = new JRadioButton ("01");
      rb1.setBounds (270, 85, 40, 25);
      rb1.addActionListener (this);
      add (rb1);
    
      rb2 = new JRadioButton ("02");
      rb2.setBounds (270, 110, 40, 25);
      rb2.addActionListener (this);
      add (rb2);
    
      rb3 = new JRadioButton ("03");
      rb3.setBounds (270, 135, 40, 25);
      rb3.addActionListener (this);
      add (rb3);

      rb4 = new JRadioButton ("04");
      rb4.setBounds (270, 160, 40, 25);
      rb4.addActionListener (this);
      add (rb4);
    
      rb5 = new JRadioButton ("05");
      rb5.setBounds (270, 185, 40, 25);
      rb5.addActionListener (this);
      add (rb5);
    
      rb6 = new JRadioButton ("06");
      rb6.setBounds (270, 210, 40, 25);
      rb6.addActionListener (this);
      add (rb6);
      
      //define ButtonGroup
      ButtonGroup bg = new ButtonGroup();
      bg.add (rb1);
      bg.add (rb2);
      bg.add (rb3);
      bg.add (rb4);
      bg.add (rb5);
      bg.add (rb6);
      
      //JTextField for quantity
      user = new JTextField (5);
      user.setBounds (510, 85, 65, 25); 
      add (user);
      
      //submit & clear button
      submit = new JButton ("Order");  
      submit.setBounds (380, 240, 100, 25);
      add (submit);

      clear = new JButton("Clear"); 
      clear.setBounds (490, 240, 100, 25);
      add (clear);

      //handle button submit action listener
      //view the input to output label
      //and write to file
      submit.addActionListener(new ActionListener(){  
          public void actionPerformed(ActionEvent e){  
             //call method              
             if(printOutput())
                writeInput();
                l_ttl.setText("TOTAL: RM" + df.format(mult));
          } 
       });

      //handle button clear action listener
      clear.addActionListener(new ActionListener(){  
          public void actionPerformed(ActionEvent e){  
             lbloutput.setText("Output"); 
             bg.clearSelection();
             cb1.setSelected(false);
             cb2.setSelected(false);
             cb3.setSelected(false);
             cb4.setSelected(false);
             cb5.setSelected(false);
             user.setText(" ");
             l_ttl.setText("TOTAL: RM" );
          }  
        });

      lbloutput = new JLabel ("Order Details");
      lbloutput.setBounds (15, 410, 100, 25);
      add (lbloutput); 
      lbloutput.setBorder(border);
      lbloutput.setVerticalAlignment(JLabel.TOP); 
      
      //add output label to scrollpane
      jsp = new JScrollPane(lbloutput);
      jsp.setBounds (20, 430, 560, 250);
      add(jsp);   
  }
  
  //handle radio button selection
   public void actionPerformed(ActionEvent ae) {
      rb_selection = ae.getActionCommand();    	   
   }
   
   //handle item listener for checkbox
   public void itemStateChanged(ItemEvent ie) {
      JCheckBox check = (JCheckBox)ie.getSource();
      list_selection += check.getText() + " ";   
   }
     //method to print output to lbloutput
    public boolean printOutput(){
      
      output = "<html>";
      output += "Thank you for your order<br><br>";   

      q = Integer.parseInt(user.getText());
      if(cb1.isSelected()){
         ttl += 3;
      }if(cb2.isSelected()){
         ttl += 3;
      }if(cb3.isSelected()){
         ttl += 3;
      }
      if(cb4.isSelected()){
         ttl += 3;
      }if(cb5.isSelected()){
         ttl += 3;
      }

      if(rb1.isSelected()){
         mult = ttl + (5*q);
      }else if(rb2.isSelected()){
         mult = ttl + (4*q);
      }else if(rb3.isSelected()){
         mult = ttl + (4*q);
      }else if(rb4.isSelected()){
         mult = ttl + (5*q);
      }else if(rb5.isSelected()){
         mult = ttl + (5*q);
      }else if(rb6.isSelected()){
         mult = ttl + (5*q);
      }
      
      output += "Drink: " + rb_selection + "<br>";            
      output += "Add On: " + list_selection + "<br>";
      output += "Quantity: " + q + "<br>";
      output += "TOTAL: RM"+df.format(mult) + "<br>";
      output += "</html>";          
      lbloutput.setText(output);
      jsp.getViewport().revalidate();
      return true;
    }
    
    //write to file
    public void writeInput(){
      File file = new File(filePath);
		FileWriter fr = null;
		BufferedWriter br = null;
		PrintWriter pr = null;
      String input = "Drink: " + rb_selection + ", Quantity: " + user.getText() + ", Add On: " + list_selection + ", RM" + df.format(mult);

      //exception implementation
		try {
			// to append to file, you need to initialize FileWriter using below constructor
			fr = new FileWriter(file, true);
			br = new BufferedWriter(fr);
			pr = new PrintWriter(br);
			pr.println(input);
		} catch (IOException e) {			
         lbloutput.setText(e.toString());
		} finally {
			try {
				pr.close();
				br.close();
				fr.close();
			} catch (IOException e) {
				lbloutput.setText(e.toString());
			}
		}
    }
}
class MenuActionListener3 implements ActionListener {
   CoffeeEspresso fp;
   //receive FormPanel class to this constructor
   public MenuActionListener3(CoffeeEspresso p){
      fp = p;
   }
    public void actionPerformed(ActionEvent e) {
       BufferedReader reader;
 	   try {
 			reader = new BufferedReader(new FileReader(fp.filePath));
 			String line = reader.readLine();
         String output="<html>";
 			while (line != null) {
 				output += line + "<br>";
 				// read next line
 				line = reader.readLine();
 			}
          output += "<br>";
          fp.lbloutput.setText(output);
 			reader.close();
 		} catch (IOException io) {
 			fp.lbloutput.setText(io.toString());
 		}
 
   }
 }
//run the application using this main
public class CustomerOrder {  
   public static void main(String[] 	args) {  
      JFrame f = new JFrame("CUSTOMER JIDZ CAFE ORDER DETAILS");
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
      CoffeeEspresso fp = new CoffeeEspresso();
      
      JMenuBar mb = new JMenuBar(); 
      // create a menu 
      JMenu x = new JMenu("Menu"); 
      
      // create menuitems 
      JMenuItem m1 = new JMenuItem("View Data"); 
      // attach listener and send FormPanel class
      m1.addActionListener(new MenuActionListener3(fp));
      
      JMenuItem m2 = new JMenuItem("Exit");  
      m2.addActionListener((event) -> System.exit(0));
      // add menu items to menu 
      x.add(m1); 
      x.add(m2);
     
      // add menu to menu bar 
      mb.add(x); 
      // add menubar to frame 
      f.setJMenuBar(mb);  
               
      //add panels to frame      
      f.add(fp);
      f.pack();
      f.setVisible(true);
   }  
}